// content.js
// AI Studio File Helper
// 1. מאפשר multiple על input[type=file]
// 2. מסיר accept כדי לראות כל סוגי הקבצים (כולל .py)
// 3. אם המשתמש בחר כמה קבצים – מעלה אותם אחד-אחד אוטומטית

(function () {
  // ----------- שדרוג אלמנט קובץ בודד -----------
  function enhanceFileInput(input) {
    if (!(input instanceof HTMLInputElement)) return;
    if (input.type !== "file") return;

    // לא לטפל פעמיים באותו input
    if (input.dataset.aiStudioEnhanced === "1") return;
    input.dataset.aiStudioEnhanced = "1";

    try {
      // לאפשר בחירה של כמה קבצים בבת אחת
      input.multiple = true;

      // לא לסנן סוגי קבצים
      input.removeAttribute("accept");

      // לחבר מאזין לאירוע change שיטפל בבחירה מרובה
      attachMultiUploadHandler(input);

      console.log("[AI Studio File Helper] Enhanced file input:", input);
    } catch (e) {
      console.warn("[AI Studio File Helper] Failed to enhance file input:", e);
    }
  }

  // ----------- חיבור לוגיקת העלאה מרובה -----------
  function attachMultiUploadHandler(input) {
    // שלא נוסיף אותו פעמיים
    if (input.dataset.aiStudioMultiHandler === "1") return;
    input.dataset.aiStudioMultiHandler = "1";

    input.addEventListener("change", function onChange(event) {
      const files = input.files;
      if (!files || files.length <= 1) {
        // קובץ אחד – ניתן ל-AI Studio לטפל כרגיל
        return;
      }

      // אם כבר רצנו על ה-input הזה – לא להיכנס ללופ אינסופי
      if (input.dataset.aiStudioBatchUploading === "1") {
        return;
      }

      // מסמן שאנחנו בתהליך העלאה מרובה
      input.dataset.aiStudioBatchUploading = "1";

      const fileArray = Array.from(files);
      console.log(
        `[AI Studio File Helper] Multi-upload detected: ${fileArray.length} files`
      );

      // נותנים לקוד המקורי של האתר לטפל בראשון כרגיל
      // ואז בתזמון הבא נתחיל להעלות את השאר
      setTimeout(() => {
        uploadRemainingFiles(input, fileArray, 1);
      }, 0);
    });
  }

  // ----------- העלאת שאר הקבצים אחד-אחד -----------
  function uploadRemainingFiles(input, files, index) {
    if (index >= files.length) {
      console.log("[AI Studio File Helper] Multi-upload finished");
      delete input.dataset.aiStudioBatchUploading;
      return;
    }

    const file = files[index];
    console.log(
      `[AI Studio File Helper] Uploading extra file ${index + 1}/${files.length}:`,
      file.name
    );

    // בונים FileList חדש עם קובץ אחד בלבד
    const dt = new DataTransfer();
    dt.items.add(file);
    input.files = dt.files;

    // משגרים אירוע change – כאילו המשתמש בחר את הקובץ הזה עכשיו
    const event = new Event("change", { bubbles: true });
    input.dispatchEvent(event);

    // מחכים קצת בין קובץ לקובץ (אפשר לכוון אם צריך)
    setTimeout(() => {
      uploadRemainingFiles(input, files, index + 1);
    }, 500); // 0.5 שניות
  }

  // ----------- סריקה + מעקב DOM -----------
  function scanAllFileInputs() {
    const inputs = document.querySelectorAll('input[type="file"]');
    inputs.forEach(enhanceFileInput);
  }

  function setupMutationObserver() {
    const observer = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        if (mutation.type === "childList") {
          mutation.addedNodes.forEach((node) => {
            if (!(node instanceof HTMLElement)) return;

            if (node.matches && node.matches('input[type="file"]')) {
              enhanceFileInput(node);
            }

            const innerInputs = node.querySelectorAll
              ? node.querySelectorAll('input[type="file"]')
              : [];
            innerInputs.forEach(enhanceFileInput);
          });
        }

        if (
          mutation.type === "attributes" &&
          mutation.target instanceof HTMLInputElement &&
          mutation.target.type === "file"
        ) {
          enhanceFileInput(mutation.target);
        }
      }
    });

    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["type"]
    });
  }

  function init() {
    console.log("[AI Studio File Helper] Content script initialized");
    scanAllFileInputs();
    setupMutationObserver();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
